import React from 'react'
import ReactDOM from 'react-dom'

import '../../css/order.css'

export default class Paid extends React.Component{
    render(){
        return(
            <div>
                <h3>已付款</h3>
            </div>
            
        )
    }
}