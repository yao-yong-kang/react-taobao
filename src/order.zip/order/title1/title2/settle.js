import React from 'react'
import ReactDOM from 'react-dom'

import '../../css/order.css'

export default class Settle extends React.Component{
    render(){
        return(
            <div>
                <h3>已结算</h3>
            </div>
            
        )
    }
}