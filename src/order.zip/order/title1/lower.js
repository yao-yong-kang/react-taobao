import React from 'react'
import ReactDOM from 'react-dom'

import '../css/order.css'

export default class Lower extends React.Component{
    render(){
        return(
            <div>
                <h3>下级订单</h3>
            </div>
            
        )
    }
}